# Screenshot Extension for Chrome


Supports cropped screenshots and full page screenshots.
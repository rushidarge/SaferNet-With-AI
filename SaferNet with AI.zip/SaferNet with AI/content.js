




// -- LOAD FUNCTION
async function RUN_MODEL(){


    MODEL_FILE = chrome.runtime.getURL('TF_MODEL/model.json')
    model = await tf.loadLayersModel(MODEL_FILE)

    console.log("Model loaded")
    console.log(model)

    replace_image(model)


}




// function that iterate over each image and check it is a safe image or not
replace_image = function (model){
    // change image source if it is a danger with changing image attribute with no error 
    console.log("Cleaning started")
    console.log(model)
    console.log("reading images")
  
    let images = document.images

    console.log("loop over images")

    for (img in images) {

        console.log(img)

        if (img < images.length){

            images[img].setAttribute('crossOrigin', 'anonymous');

            try{
                f_img = tf.image.resizeBilinear(tf.browser.fromPixels(images[img]), [224, 224]).div(255).expandDims()
                

                if (Array.from(model.predict(f_img).dataSync())[0] > 0.5) {
                    console.log(`Replacing img ${img}`)
                    document.images[img].src = `https://picsum.photos/${document.images[img].clientWidth}/${document.images[img].clientHeight}?random=1`
                } else {
                    console.log("Safe image")
                }
            }catch{
                console.log("PASSED")
            }


            // f_img.dispose()



        }

    }

    



}



// -- LOAD MODEL 

window.addEventListener ("load", () => {

    setTimeout( RUN_MODEL , 1000)

}, false);






